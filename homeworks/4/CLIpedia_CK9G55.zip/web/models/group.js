const Group = {
    id: Number,
    name: String,
    icon_link: String,
    description: String
}

module.exports = Group;