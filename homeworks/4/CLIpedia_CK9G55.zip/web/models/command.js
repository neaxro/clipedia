const Command = {
    id: Number,
    examples: [],   // Strings
    links: [],      // Strings
    badges: [],     // Strings
    group_id: Number
}

module.exports = Command;
